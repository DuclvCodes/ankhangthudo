<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="properties-ordering-wrapper">
