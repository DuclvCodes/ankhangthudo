<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="alert alert-warning not-allow-wrapper">
	<?php echo __( 'You are not allowed to access this page.', 'wp-realestate' ); ?>
</div><!-- /.alert -->
